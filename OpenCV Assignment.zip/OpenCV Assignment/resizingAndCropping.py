# Resizing and cropping images

import cv2
import numpy as np

img = cv2.imread("E:\pycharm\OpenCVPython\OpenCV Assignment\dog 1.jpg")

imgResize= cv2.resize(img, (300,200))

imgCropped = img[0:200,200:500]

cv2.imshow("Output", img)
cv2.imshow("Resized Output", imgResize)
cv2.imshow("Cropped Output", imgCropped)
cv2.waitKey(0)

