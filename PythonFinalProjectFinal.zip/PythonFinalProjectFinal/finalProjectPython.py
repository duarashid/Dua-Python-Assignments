import cv2
import pytesseract
import os

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

plate_cascade = cv2.CascadeClassifier(r"E:\pycharm\OpenCVPython\PythonFinalProjectFinal\haarcascade_russian_plate_number.xml")
image_folder = r"E:\pycharm\OpenCVPython\PythonFinalProjectFinal\input_images"


image_files = [file for file in os.listdir(image_folder) if file.endswith((".jpg", ".jpeg", ".png"))]

for image_file in image_files:
        image_path = os.path.join(image_folder, image_file)
        img = cv2.imread(image_path)
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

        for (x, y, w, h) in plates:
            plate_roi = img[y:y + h, x:x + w]
            plate_text = pytesseract.image_to_string(plate_roi, config='--psm 7')


            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(img, plate_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        cv2.imshow("Result", img)
        cv2.waitKey(0)

cv2.destroyAllWindows()